class RigidBody{
    vx = 0;
    vy = 0;
    ax = 0;
    ay = 0;
}