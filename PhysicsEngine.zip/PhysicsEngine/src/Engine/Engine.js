
class Engine{
    bodies = [];
    ctx;
    world;
    animationFrameId;
    constructor(world){
        this.ctx = world.ctx;
        this.world = world;
        // Bind the update method to ensure it has the correct context
        this.update = this.update.bind(this);
    }

    update(){
        this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);
        for(let i = 0;i<this.bodies.length;i++){
            this.bodies[i].draw(this.ctx);
            this.bodies[i].move();

            //check boundaries are activated in the world
            if(this.world.isBounderiesActive){
                this.bodies[i].setBoundaries(this.ctx.canvas);
            }
        }
        this.animationFrameId = requestAnimationFrame(this.update);
    }

    startEngine() {
        this.update();
    }
    
    stopEngine() {
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
        }
    }


}

export default Engine;